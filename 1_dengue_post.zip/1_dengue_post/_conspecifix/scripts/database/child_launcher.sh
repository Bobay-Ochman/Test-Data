#!/usr/bin/env bash

python child_runner.py