#!/bin/bash

#runner takes three args:
# suspectedSpecies (a string)
# strain name
# upload TimeStamp folder
python runner.py Mycobacterium_africanum GCA_001544855.1_ASM154485v1_genomic 1492458248173

#python concat85_arr.py Mycobacterium_africanum GCA_001544855.1_ASM154485v1_genomic 1492458248173